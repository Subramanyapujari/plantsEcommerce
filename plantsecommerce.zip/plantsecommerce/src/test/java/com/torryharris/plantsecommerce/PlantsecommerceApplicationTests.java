package com.torryharris.plantsecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlantsecommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
